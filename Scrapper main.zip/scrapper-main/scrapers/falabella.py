"""
Scraper para Falabella Perú usando Playwright (headless browser).
Falabella usa JavaScript pesado para renderizar productos.
"""
import time
import random
import logging
from typing import List, Optional
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

from .base import BaseScraper, ProductResult
from config import MIN_DELAY, MAX_DELAY
from utils import normalize_query


class FalabellaScraper(BaseScraper):
    """Scraper para Falabella Perú usando Playwright."""
    
    BASE_URL = "https://www.falabella.com.pe"
    SEARCH_URL = f"{BASE_URL}/falabella-pe/search"
    
    @property
    def nombre_tienda(self) -> str:
        return "Falabella"
    
    @property
    def emoji(self) -> str:
        return "🟠"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Busca productos en Falabella usando Playwright.
        """
        results = []
        safe_query = normalize_query(query)
        search_url = f"{self.SEARCH_URL}?Ntt={safe_query}"
        
        time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page(user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                
                page.goto(search_url, timeout=30000)
                
                # Esperar productos - Falabella usa data-pod
                page.wait_for_selector('[data-pod], .pod-item, .search-results-item', timeout=15000)
                
                # Selector mas amplio
                items = page.query_selector_all('[data-pod], .pod-item')
                
                if not items:
                    # Fallback: buscar cualquier producto con precio
                    items = page.query_selector_all('.search-results-item, .grid-pod')
                
                for i, item in enumerate(items[:max_results]):
                    try:
                        # Título: Usar selector más específico primero
                        title_el = item.query_selector('b[id*="testId-pod-displaySubTitle"]')
                        if not title_el:
                            title_el = item.query_selector('.pod-subTitle, a[data-title], .pod-title')
                        if not title_el:
                            link_el = item.query_selector('a[href*="/product/"], a[href*="/p/"]')
                            if link_el:
                                title_el_text = link_el.get_attribute('title') or link_el.inner_text()
                                titulo = title_el_text.strip()
                            else:
                                continue
                        else:
                            titulo = title_el.inner_text().strip()
                        
                        # Link
                        link_el = item.query_selector('a[href*="/product/"], a[href*="/p/"]')
                        url = link_el.get_attribute('href') if link_el else ""
                        if url and not url.startswith('http'):
                            url = f"{self.BASE_URL}{url}"
                        
                        # Precio
                        price_el = item.query_selector('.prices-0 span, .copy10, [class*="price"] span')
                        if not price_el:
                            continue
                        
                        price_text = price_el.inner_text()
                        # Format: "S/2.499" -> 2499
                        price_text = price_text.replace('S/', '').replace('.', '').replace(',', '').strip()
                        precio = float(price_text)
                        
                        results.append(ProductResult(
                            nombre=titulo,
                            precio=precio,
                            precio_original=None,
                            descuento=None,
                            tienda=self.nombre_tienda,
                            url=url,
                            sku="",
                            disponible=True,
                            vendedor="Falabella"
                        ))
                        
                    except Exception as e:
                        self.logger.warning(f"Error parsing Falabella item: {e}")
                        continue
                        
                browser.close()
                
        except PlaywrightTimeout:
            self.logger.error("Timeout esperando resultados de Falabella")
        except Exception as e:
            self.logger.error(f"Error Playwright Falabella: {e}")
            
        return results
