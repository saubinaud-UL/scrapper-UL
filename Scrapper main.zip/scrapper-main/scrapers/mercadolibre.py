"""
Scraper para MercadoLibre Perú usando Playwright (headless browser).
Necesario porque ML usa protección anti-bot con desafios JavaScript.
"""
import time
import random
import logging
from typing import List, Optional
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

from .base import BaseScraper, ProductResult
from config import MIN_DELAY, MAX_DELAY
from utils import normalize_query, check_relevance


class MercadoLibreScraper(BaseScraper):
    """Scraper para MercadoLibre Perú usando Playwright (headless Chrome)."""
    
    SEARCH_URL = "https://listado.mercadolibre.com.pe"
    
    @property
    def nombre_tienda(self) -> str:
        return "MercadoLibre"
    
    @property
    def emoji(self) -> str:
        return "🟡"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Busca productos en MercadoLibre usando Playwright headless browser.
        """
        results = []
        safe_query = normalize_query(query).replace(" ", "-")
        search_url = f"{self.SEARCH_URL}/{safe_query}"
        
        time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled"]
                )
                context = browser.new_context(
                    user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                )
                page = context.new_page()
                page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                
                page.goto(search_url, timeout=30000)
                
                # Esperar a que cargue el contenido dinámico (más flexible)
                try:
                    page.wait_for_selector('li.ui-search-layout__item, ol.ui-search-layout', timeout=5000)
                except:
                    pass
                
                # Selector de items
                items = page.locator('ol.ui-search-layout li.ui-search-layout__item')
                count = items.count()
                self.logger.info(f"MercadoLibre: Found {count} raw items")
                
                for i in range(min(count, 15)): # Check more items
                    if len(results) >= max_results:
                        break
                        
                    item = items.nth(i)
                    try:
                        # Título y Link
                        title_el = item.locator('h2.ui-search-item__title, .poly-component__title')
                        if not title_el.first.is_visible(): 
                            self.logger.warning(f"Item {i}: Title not visible")
                            continue
                        titulo = title_el.first.inner_text().strip()
                        
                        # Relevance Check
                        if not check_relevance(titulo, query):
                            self.logger.warning(f"Item {i} '{titulo}': Relevance Check Failed")
                            continue
                        
                        link_el = item.locator('a.ui-search-link, a.poly-component__title').first
                        if not link_el.is_visible():
                            self.logger.warning(f"Item {i}: Link not visible")
                            continue
                        url = link_el.get_attribute('href')
                            
                        # Precio
                        price_el = item.locator('.andes-money-amount__fraction, .price-tag-fraction').first
                        if not price_el.is_visible():
                            self.logger.warning(f"Item {i}: Price not visible")
                            continue
                            
                        price_text = price_el.inner_text().replace('.', '').replace(',', '')
                        precio = float(price_text)
                        
                        self.logger.info(f"Item {i}: SUCCESS - {titulo} ({precio})")
                        
                        results.append(ProductResult(
                            nombre=titulo,
                            precio=precio,
                            precio_original=None,
                            descuento=None,
                            tienda=self.nombre_tienda,
                            url=url,
                            sku="",
                            disponible=True,
                            vendedor="MercadoLibre"
                        ))
                        
                    except Exception as e:
                        self.logger.warning(f"Error parsing ML item {i}: {e}")
                        continue
                        
                browser.close()
                
        except PlaywrightTimeout:
            self.logger.error("Timeout esperando resultados de MercadoLibre")
        except Exception as e:
            self.logger.error(f"Error Playwright MercadoLibre: {e}")
            
        return results
