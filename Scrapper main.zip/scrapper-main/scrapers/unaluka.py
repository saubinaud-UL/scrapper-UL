"""
Scraper para UnaLuka usando Playwright con JavaScript evaluation.
UnaLuka es una tienda Shopify peruana.
"""
import time
import random
import re
from typing import List, Optional
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

from .base import BaseScraper, ProductResult
from config import MIN_DELAY, MAX_DELAY
from utils import normalize_query, check_relevance


class UnaLukaScraper(BaseScraper):
    """Scraper para UnaLuka usando Playwright con JS evaluation."""
    
    BASE_URL = "https://unaluka.com"
    SEARCH_URL = f"{BASE_URL}/search"
    
    @property
    def nombre_tienda(self) -> str:
        return "UnaLuka"
    
    @property
    def emoji(self) -> str:
        return "🦊"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Busca productos en UnaLuka.
        
        ESTRATEGIA OPTIMIZADA:
        - Si el query parece ASIN (B0...) → Ir DIRECTO a search?view=json (indexa SKUs)
        - Si es texto normal → Usar suggest.json (más rápido para autocomplete)
        """
        import requests
        
        results = []
        safe_query = normalize_query(query)
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        }
        
        # DETECTAR SI ES ASIN (Patrón: B0 + 8 caracteres alfanuméricos)
        is_asin_search = bool(re.match(r'^B0[0-9A-Z]{8}$', safe_query.upper()))
        
        if is_asin_search:
            # ============================================
            # RUTA RÁPIDA PARA ASIN: Directo a view=json
            # ============================================
            try:
                search_json_url = f"{self.SEARCH_URL}"
                search_params = {'q': safe_query, 'view': 'json'}
                
                r = requests.get(search_json_url, params=search_params, headers=headers, timeout=10)
                if r.status_code == 200:
                    try:
                        # Limpiar JSON malformado (coma trailing antes de ])
                        clean_text = re.sub(r',\s*]', ']', r.text)
                        clean_text = re.sub(r',\s*}', '}', clean_text)
                        items_db = __import__('json').loads(clean_text)
                    except:
                        items_db = []
                        
                    if isinstance(items_db, list):
                        for item in items_db:
                            try:
                                title = item.get('title', '')
                                price_raw = item.get('price', '0')
                                
                                price = 0.0
                                if isinstance(price_raw, (int, float)):
                                    price = float(price_raw)
                                else:
                                    clean_p = re.sub(r'[^0-9.]', '', str(price_raw).replace(',', ''))
                                    price = float(clean_p) if clean_p else 0.0
                                
                                handle = item.get('handle', '')
                                if '/products/' in handle:
                                     full_url = "https://unaluka.com" + handle.split('?')[0]
                                else:
                                     full_url = f"https://unaluka.com/products/{handle}"
                                     
                                img = item.get('featured_image', '')
                                if img and img.startswith('//'): img = 'https:' + img
                                
                                prod = ProductResult(
                                   nombre=title,
                                   precio=price,
                                   precio_original=None,
                                   descuento=None,
                                   tienda=self.nombre_tienda,
                                   url=full_url,
                                   
                                   vendedor='UnaLuka',
                                   disponible=item.get('available', True)
                               )
                                results.append(prod)
                            except: continue
            except Exception as e:
                print(f"Error ASIN Search: {e}")
        
        else:
            # ============================================
            # RUTA NORMAL PARA TEXTO: suggest.json (rápido)
            # ============================================
            api_url = f"{self.BASE_URL}/search/suggest.json"
            params = {
                'q': safe_query,
                'resources[type]': 'product',
                'resources[limit]': max_results + 2,
                'resources[options][unavailable_products]': 'last'
            }
            
            try:
                resp = requests.get(api_url, params=params, headers=headers, timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    products_data = data.get('resources', {}).get('results', {}).get('products', [])
                    
                    for p in products_data:
                        try:
                            title = p.get('title', '')
                            price_str = p.get('price', '0')
                            url = p.get('url', '')
                            if url and not url.startswith('http'):
                                url = self.BASE_URL + url
                                
                            price = 0.0
                            if isinstance(price_str, (int, float)):
                                price = float(price_str)
                            else:
                                price_val = re.sub(r'[^0-9.]', '', str(price_str).replace(',', ''))
                                price = float(price_val) if price_val else 0.0

                            img = p.get('image', '')
                            
                            prod = ProductResult(
                                nombre=title,
                                precio=price,
                                precio_original=None,
                                descuento=None,
                                tienda=self.nombre_tienda,
                                url=url,
                                
                                vendedor=p.get('vendor', 'UnaLuka'),
                                disponible=True
                            )
                            results.append(prod)
                        except: continue
            except Exception: pass
            
            # Fallback a view=json si suggest no devuelve nada (para texto que matchea descripción/SKU)
            if not results:
                 try:
                     search_json_url = f"{self.SEARCH_URL}"
                     search_params = {'q': safe_query, 'view': 'json'}
                     
                     r = requests.get(search_json_url, params=search_params, headers=headers, timeout=10)
                     if r.status_code == 200:
                         try:
                             # Limpiar JSON malformado (coma trailing)
                             clean_text = re.sub(r',\s*]', ']', r.text)
                             clean_text = re.sub(r',\s*}', '}', clean_text)
                             items_db = __import__('json').loads(clean_text)
                         except:
                             items_db = []
                             
                         if isinstance(items_db, list):
                             for item in items_db:
                                 try:
                                     title = item.get('title', '')
                                     price_raw = item.get('price', '0')
                                     
                                     price = 0.0
                                     if isinstance(price_raw, (int, float)):
                                         price = float(price_raw)
                                     else:
                                         clean_p = re.sub(r'[^0-9.]', '', str(price_raw).replace(',', ''))
                                         price = float(clean_p) if clean_p else 0.0
                                     
                                     handle = item.get('handle', '')
                                     if '/products/' in handle:
                                          full_url = "https://unaluka.com" + handle.split('?')[0]
                                     else:
                                          full_url = f"https://unaluka.com/products/{handle}"
                                          
                                     img = item.get('featured_image', '')
                                     if img and img.startswith('//'): img = 'https:' + img
                                     
                                     prod = ProductResult(
                                        nombre=title,
                                        precio=price,
                                        precio_original=None,
                                        descuento=None,
                                        tienda=self.nombre_tienda,
                                        url=full_url,
                                        
                                        vendedor='UnaLuka',
                                        disponible=item.get('available', True)
                                    )
                                     results.append(prod)
                                 except: continue
                 except Exception: pass

        # Filtrar y Limitar
        final_results = []
        for prod in results:
            # Para ASIN, no filtramos por relevancia de texto (el ASIN es match exacto)
            if is_asin_search or check_relevance(prod, query):
                final_results.append(prod)
        
        return final_results[:max_results]

    def get_product_by_url(self, url: str) -> Optional[ProductResult]:
        """Obtiene un producto específico por URL."""
        if not url: return None
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, args=["--disable-blink-features=AutomationControlled"])
                page = browser.new_page()
                page.goto(url, timeout=45000)
                
                try:
                    # Esperar algo visual crítico en lugar de networkidle que falla a veces
                    page.wait_for_selector('h1', timeout=15000)
                    time.sleep(3) # Espera de seguridad para JS dinámico
                except: pass
                
                # Extraer datos específicos de pagina de producto
                data = page.evaluate(r'''() => {
                    const title = document.querySelector('h1') ? document.querySelector('h1').innerText.trim() : "";
                    
                    let price = 0;
                    // Probar varios selectores de precio
                    const selectors = ['.price', '#ProductPrice', '.product-price', '.current-price', '.price__current'];
                    for (let s of selectors) {
                        let el = document.querySelector(s);
                        if(el && el.innerText.match(/[0-9]/)) {
                            let txt = el.innerText.replace(/[^0-9.]/g, '');
                            let p = parseFloat(txt);
                            if(p>0) { price=p; break; }
                        }
                    }
                    
                    // Buscar ASIN Pattern
                    // Prioridad 1: Label explícito "SKU del producto:"
                    const bodyText = document.body.innerText;
                    let sku = "";
                    
                    // Regex más flexible para posibles saltos de linea o espacios
                    const explicitMatch = bodyText.match(/SKU del producto:[\s\n\r]*(B0[0-9A-Z]{8})/i);
                    if (explicitMatch) {
                        sku = explicitMatch[1];
                    } else {
                        // Prioridad 2: Buscar cualquier B0... aislado
                        const asinMatch = bodyText.match(/\b(B0[0-9A-Z]{8})\b/);
                        if(asinMatch) sku = asinMatch[1];
                    }

                    // Título fallback si no hay H1
                    if(!title) {
                         const meta = document.querySelector('meta[property="og:title"]');
                         if(meta) return { nombre: meta.content, price: price, sku: sku, url: document.location.href, tienda: 'UnaLuka', disponible: true, vendedor: "UnaLuka", descuento: null, precio_original: null };
                    }
                    
                    return {
                        nombre: title,
                        precio: price,
                        precio_original: null,
                        descuento: null, // CORRECCIÓN CRITICA: Campo obligatorio
                        tienda: 'UnaLuka',
                        url: document.location.href,
                        vendedor: "UnaLuka Store",
                        sku: sku,
                        disponible: true
                    };
                }''')
                
                if data and data['nombre']:
                    prod = ProductResult(**data)
                    prod.tienda = self.nombre_tienda
                    return prod
                    
        except Exception as e:
            print(f"Error scraping Unaluka URL: {e}")
            
        return None
