"""
Scraper para Ripley Perú usando Google SERP Simulation (Evasión Total).
"""
from typing import List, Optional
from curl_cffi import requests
from bs4 import BeautifulSoup
from .base import BaseScraper, ProductResult
from utils import normalize_query
import logging
import re
import urllib.parse
import time
import random

class RipleyScraper(BaseScraper):
    """
    Scraper para Ripley Perú.
    Estrategia: Google SERP Simulation.
    Motivo: Cloudflare Turnstile bloquea 100% de peticiones directas.
    """
    
    BASE_URL = "https://simple.ripley.com.pe"
    
    @property
    def nombre_tienda(self) -> str:
        return "Ripley"
    
    @property
    def emoji(self) -> str:
        return "🟢"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """Busca productos en Ripley simulando búsqueda en Google."""
        results = []
        # Use main domain for broader index coverage
        safe_query = f"site:ripley.com.pe {query}"
        
        # Rotar dominios de Google para evitar bloqueos
        tlds = ["com.pe", "com", "cl"]
        tld = random.choice(tlds)
        search_url = f"https://www.google.{tld}/search"
        
        params = {
            "q": safe_query,
            "num": max_results + 3, # Pedir un poco más
            "hl": "es"
        }
        
        try:
            # Random sleep corto
            time.sleep(random.uniform(0.5, 1.5))
            
            response = requests.get(
                search_url,
                params=params,
                impersonate="chrome120",
                timeout=15
            )
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'lxml')
                
                # Google suele usar div.g para resultados
                # Ojo: la estructura cambia, hay que ser flexible
                # Buscamos todos los enlaces que coincidan con productos de Ripley
                
                links_seen = set()
                
                for a in soup.select('a[href]'):
                    href = a.get('href')
                    
                    # Limpiar URL de redirecciones de google (/url?q=...)
                    if "/url?q=" in href:
                         parsed = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
                         href = parsed.get('q', [''])[0]
                    
                    if not href: continue
                    
                    # Validar dominio y patrón de producto
                    if "simple.ripley.com.pe" in href and ("/p/" in href or "producto-mpm" in href):
                        if href in links_seen: continue
                        links_seen.add(href)
                        
                        # Intentar extraer título del propio link (h3 suele estar dentro)
                        title_el = a.find_previous('h3') or a.find('h3') 
                        if not title_el:
                            # Fallback: usar el texto del link o buscar nombre en URL
                            title_text = a.get_text().strip()
                            if not title_text or "http" in title_text:
                                # Extraer de URL: .../iphone-15-128gb...
                                slug = href.split('/')[-1]
                                title_text = slug.replace('-', ' ').title()
                        else:
                            title_text = title_el.get_text().strip()
                        
                        # Relevance Check
                        from utils import check_relevance
                        if not check_relevance(title_text, query):
                            continue
                        
                        # Intentar extraer precio del TEXTO del snippet o título
                        # Google a veces muestra: "S/ 3,599.00 - Ripley..." o "iPhone 15 ... S/3599"
                        snippet_el = a.find_next('div', style='-webkit-line-clamp:2') or a.find_next('div', class_='VwiC3b') # Clases comunes de snippet
                        snippet_text = snippet_el.get_text() if snippet_el else ""
                        
                        full_text = f"{title_text} {snippet_text}"
                        
                        # Regex para buscar precios: S/ 1,234.00 o S/1.234
                        # Buscamos patrones con "S/" seguido de números
                        import re
                        price_match = re.search(r'S/\s?[\d,.]+', full_text)
                        
                        extracted_price = 0.0
                        if price_match:
                            try:
                                # Limpiar string de precio
                                p_str = price_match.group(0).replace('S/', '').replace(',', '').strip()
                                # A veces google pone puntos como miles si es es-PE? O comas?
                                # Asumimos formato estandar: eliminar comas, mantener punto decimal si existe
                                # Si hay multiples puntos, es miles.
                                if p_str.count('.') > 1:
                                    p_str = p_str.replace('.', '')
                                
                                extracted_price = float(p_str)
                            except:
                                pass
                        
                        results.append(ProductResult(
                            nombre=title_text,
                            precio=extracted_price, # Ahora intentamos mandar precio
                            precio_original=None,
                            descuento=None,
                            tienda=self.nombre_tienda,
                            url=href,
                            sku="",
                            disponible=True,
                            vendedor="Ripley"
                        ))
                        
                        if len(results) >= max_results:
                            break
            
            elif response.status_code == 429:
                self.logger.warning("Google bloqueó requests (429)")
                
        except Exception as e:
            self.logger.error(f"Error Ripley/Google: {e}")
            
        return results
