"""
Clase base abstracta para todos los scrapers.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional
import logging


@dataclass
class ProductResult:
    """Resultado de búsqueda de producto."""
    nombre: str
    precio: float
    precio_original: Optional[float]
    descuento: Optional[str]
    tienda: str
    url: str
    sku: Optional[str] = None
    disponible: bool = True
    vendedor: Optional[str] = None


class BaseScraper(ABC):
    """Clase base para todos los scrapers."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
    
    @property
    @abstractmethod
    def nombre_tienda(self) -> str:
        """Nombre de la tienda para mostrar."""
        pass
    
    @property
    @abstractmethod
    def emoji(self) -> str:
        """Emoji representativo de la tienda."""
        pass
    
    @abstractmethod
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Busca productos y retorna lista de resultados.
        
        Args:
            query: Término de búsqueda
            max_results: Número máximo de resultados
            
        Returns:
            Lista de ProductResult
        """
        pass
    
    def safe_search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Wrapper con manejo de errores.
        
        Args:
            query: Término de búsqueda
            max_results: Número máximo de resultados
            
        Returns:
            Lista de ProductResult (vacía si hay error)
        """
        try:
            return self.search(query, max_results)
        except Exception as e:
            self.logger.error(f"Error en búsqueda '{query}': {e}")
            return []
