"""
Scraper para Amazon usando Playwright con JavaScript evaluation.
Usa evaluación JS directa para extracción robusta de datos + Offer Listing Fallback.
Optimizado para EVITAR precios "Renewed" buscando activamente la condición "New".
"""
import time
import random
import re
import json
from typing import List, Optional
from urllib.parse import quote_plus
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

from .base import BaseScraper, ProductResult
from config import MIN_DELAY, MAX_DELAY
from utils import normalize_query, check_relevance


class AmazonScraper(BaseScraper):
    """Scraper para Amazon usando Playwright con JS evaluation."""
    
    BASE_URL = "https://www.amazon.com"
    SEARCH_URL = f"{BASE_URL}/s"
    
    @property
    def nombre_tienda(self) -> str:
        return "Amazon"
    
    @property
    def emoji(self) -> str:
        return "🟠"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Busca productos en Amazon usando Playwright + JavaScript.
        Filtra activamente productos "Renewed" o "Refurbished".
        """
        results = []
        # Construir URL de búsqueda
        search_url = f"https://www.amazon.com/s?k={quote_plus(query)}&i=computers&language=en_US"
        self.logger.info(f"Amazon Searching: {search_url}")
        
        time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled"]
                )
                context = browser.new_context(
                    user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    locale='en-US',
                    geolocation={'latitude': 40.7128, 'longitude': -74.0060}, # New York
                    permissions=['geolocation'],
                    timezone_id='America/New_York'
                )
                
                # Forzar moneda USD y Lenguaje EN-US mediante cookies y headers
                context.add_cookies([
                    { 'name': 'i18n-prefs', 'value': 'USD', 'domain': '.amazon.com', 'path': '/' },
                    { 'name': 'lc-main', 'value': 'en_US', 'domain': '.amazon.com', 'path': '/' }
                ])
                
                page = context.new_page()
                page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                
                page.goto(search_url, timeout=60000)
                
                # Esperar resultados
                try:
                    page.wait_for_selector('div[data-component-type="s-search-result"]', timeout=10000)
                except:
                    pass
                
                # Extraer datos usando JavaScript
                items_data = page.evaluate(r'''() => {
                    const items = document.querySelectorAll('div[data-component-type="s-search-result"]');
                    const results = [];
                    
                    items.forEach((item) => {
                        const asin = item.getAttribute('data-asin');
                        if (!asin) return;
                        
                        // Título
                        const titleEl = item.querySelector('h2 a span') || item.querySelector('h2 span');
                        const title = titleEl ? titleEl.textContent.trim() : '';
                        
                        // Link
                        const linkEl = item.querySelector('h2 a');
                        const link = linkEl ? linkEl.href : '';
                        
                        // Check RENEWED en Search Result
                        if (title.toLowerCase().includes('renewed') || title.toLowerCase().includes('refurbished')) {
                            return; // Skip renewed items early
                        }
                        
                        // Precio - preferir whole+fraction (más confiable)
                        let price = 0;
                        
                        // Opción 1: Precio por partes (más confiable)
                        const priceWhole = item.querySelector('span.a-price-whole');
                        const priceFraction = item.querySelector('span.a-price-fraction');
                        if (priceWhole) {
                            // Whole tiene formato "397." - limpiar
                            const whole = priceWhole.textContent.replace(/[^0-9]/g, '');
                            const fraction = priceFraction ? priceFraction.textContent.replace(/[^0-9]/g, '') : '00';
                            if (whole) {
                                price = parseFloat(whole + '.' + fraction) || 0;
                            }
                        }
                        
                        // Opción 2: Fallback a offscreen
                        if (price === 0) {
                            const priceOffscreen = item.querySelector('span.a-offscreen');
                            if (priceOffscreen) {
                                let priceText = priceOffscreen.textContent;
                                
                                // Skip si dice "X sizes" u otro texto no-precio
                                if (priceText.match(/sizes?|colors?|options?/i)) {
                                    // No es un precio, ignorar
                                } else {
                                    // Limpiar y parsear $XX.XX o US$XX.XX
                                    const match = priceText.match(/(?:US\s*\$|USD|\$)\s*([0-9,]+(?:\.[0-9]{2})?)/);
                                    
                                    if (match) {
                                        priceText = match[1];
                                        priceText = priceText.replace(/,/g, '');
                                        price = parseFloat(priceText) || 0;
                                    }
                                }
                            }
                        }
                        
                        // Opción 3: Fallback Buying Options (si dice "$XX.XX" en algún lado)
                        if (price === 0 && link) {
                            // A veces el precio está en un texto "from $XX.XX"
                            const allText = item.innerText;
                            const match = allText.match(/from\s*\$([0-9,.]+)/) || allText.match(/\$([0-9,.]+)/);
                             if (match) {
                                price = parseFloat(match[1].replace(/,/g, '')) || 0;
                            }
                        }

                        if (title && price > 0) {
                            results.push({
                                asin: asin,
                                title: title,
                                price: price,
                                link: link
                            });
                        }
                    });
                    
                    return results;
                }''')
                
                self.logger.info(f"Amazon: Found {len(items_data)} valid items via JS (Refurbished filtered)")
                
                for item in items_data:
                    if len(results) >= max_results:
                        break
                    
                    results.append(ProductResult(
                        nombre=item['title'],
                        precio=item['price'],
                        precio_original=None,
                        descuento=None,
                        tienda=self.nombre_tienda,
                        url=item['link'],
                        sku=item['asin'],
                        disponible=True,
                        vendedor="Amazon"
                    ))
                
                browser.close()
                
        except Exception as e:
            self.logger.error(f"Error Playwright Amazon: {e}")
            
        return results

    def get_product_by_asin(self, asin: str) -> Optional[ProductResult]:
        """
        Obtiene detalles, asegurando precio "NUEVO" y "PRINCIPAL" (Big Price).
        
        Estrategia HIBRIDA V6 (Surgical Fix):
        1. OLP (New) PRIMERO.
        2. BIG DOM PRICE: V3 lógica (funciona) + Filtro de tachado (evita $16.98 phantom).
        """
        product_url = f"https://www.amazon.com/dp/{asin}?language=en_US"
        self.logger.info(f"Amazon Fetching ASIN: {product_url}")
        
        result = None
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled"]
                )
                context = browser.new_context(
                    user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                    locale='en-US',
                    geolocation={'latitude': 40.7128, 'longitude': -74.0060}, # New York
                    permissions=['geolocation'],
                    timezone_id='America/New_York'
                )
                
                # Cookies esenciales
                context.add_cookies([
                    { 'name': 'i18n-prefs', 'value': 'USD', 'domain': '.amazon.com', 'path': '/' },
                    { 'name': 'lc-main', 'value': 'en_US', 'domain': '.amazon.com', 'path': '/' }
                ])
                
                page = context.new_page()
                page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                
                page.goto(product_url, timeout=60000)
                
                # --- CHECK RENEWED STATE ---
                is_renewed_page = page.evaluate(r'''() => {
                    const titleEl = document.querySelector('#productTitle');
                    const title = titleEl ? titleEl.innerText.toLowerCase() : "";
                    const breadcrumbs = document.querySelector('#wayfinding-breadcrumbs_feature_div');
                    const bcText = breadcrumbs ? breadcrumbs.innerText.toLowerCase() : "";
                    
                    if (title.includes('renewed') || title.includes('refurbished') || title.includes('(renewed)')) return true;
                    if (bcText.includes('renewed') || bcText.includes('refurbished')) return true;
                    return false;
                }''')
                
                price = 0
                source = "None"
                
                # --- FASE 1: OLP (High Trust, Low Speed) ---
                self.logger.info("  -> Priority Check: Offer Listing Page (New)...")
                olp_price = self._fetch_offer_listing_price(context, asin)
                
                if olp_price > 0:
                    price = olp_price
                    source = "OLP (Verified New)"
                elif is_renewed_page:
                    self.logger.warning("  -> Page is Renewed and no New OLP found.")
                    price = 0
                else:
                    # --- FASE 2: BIG DOM PRICE (V3 + Strikeout Filter) ---
                    # Regresamos a la logica V3 que funcionó, con un tweak minimo
                    self.logger.info("  -> OLP empty. Checking Big DOM Price (Surgical V6)...")
                    
                    dom_data = page.evaluate(r'''() => {
                        const corePrice = document.querySelector('#corePrice_feature_div') || 
                                          document.querySelector('#corePriceDisplay_desktop_feature_div') ||
                                          document.querySelector('#apex_desktop') ||
                                          document.querySelector('.a-price'); 
                                          
                        if (!corePrice) return 0;
                        
                        // TWEAK: Validar que no sea un bloque de texto tachado
                        // Buscamos prioritariamente .a-price que NO tenga .a-text-price
                        let priceEl = corePrice.querySelector('.a-price:not(.a-text-price) .a-offscreen');
                        
                        // Si no encontramos uno limpio, buscamos generico (V3 behavior) pero validando el texto
                        if (!priceEl) {
                             priceEl = corePrice.querySelector('.a-price .a-offscreen') || corePrice.querySelector('.a-offscreen');
                        }
                        
                        if (priceEl) {
                             // Safety check: is parent strikeout?
                             if (priceEl.closest('.a-text-price')) return 0;

                             const match = priceEl.innerText.match(/(?:US\s*\$|USD|\$)\s*([0-9,]+(?:\.[0-9]{2})?)/);
                             if (match) return parseFloat(match[1].replace(/,/g, ''));
                        }
                        
                        return 0;
                    }''')
                    
                    if dom_data > 0:
                        price = dom_data
                        source = "DOM (Big Price)"
                    else:
                        # Fallback JSON
                        self.logger.info("  -> DOM empty. Checking JSON...")
                        json_price = self._extract_price_from_json(page.content())
                        if json_price > 0:
                            price = json_price
                            source = "JSON Fallback"


                # TITULO
                title = page.evaluate(r'''() => {
                     const titleEl = document.querySelector('#productTitle');
                     if (titleEl) return titleEl.textContent.trim();
                     return document.title.replace('Amazon.com:', '').replace('Amazon.com', '').trim();
                }''')
                
                # Resultado final
                if title:
                    self.logger.info(f"  -> SUCCESS: Found price {price} via {source}")
                    sku_display = asin
                    if price <= 0:
                         sku_display = "Precio no encontrado"
                         
                    result = ProductResult(
                        nombre=title,
                        precio=price,
                        precio_original=None,
                        descuento=None,
                        tienda=self.nombre_tienda,
                        url=product_url,
                        sku=sku_display,
                        disponible=True,
                        vendedor="Amazon"
                    )
                
                browser.close()
                
        except Exception as e:
            self.logger.error(f"Error getting ASIN {asin}: {e}")
            
        return result

    def _extract_price_from_json(self, html: str) -> float:
        """Busca precios en bloques JSON conocidos de Amazon."""
        try:
            match = re.search(r'"priceToPay":\s*\{\s*"amount":\s*([0-9.]+)', html)
            if match: return float(match.group(1))
            
            match = re.search(r'"buyingPrice":\s*([0-9.]+)', html)
            if match: return float(match.group(1))
            
            match = re.search(r'"displayPrice":\s*"([^"]+)"', html)
            if match:
                val = match.group(1).replace('$', '').replace(',', '')
                try: return float(val)
                except: pass
            return 0.0
        except:
            return 0.0

    def _fetch_offer_listing_price(self, context, asin: str) -> float:
        """Navega a la página de ofertas (/gp/offer-listing/)."""
        try:
            page = context.new_page()
            url = f"https://www.amazon.com/gp/offer-listing/{asin}/ref=dp_olp_new_mbc?ie=UTF8&condition=new"
            page.goto(url, timeout=15000)
            
            try:
                page.wait_for_selector('.olpOfferPrice, .a-price', timeout=5000)
            except:
                pass
                
            price = page.evaluate(r'''() => {
                const selectors = ['span.olpOfferPrice', '.a-price .a-offscreen', '.a-price'];
                for (let s of selectors) {
                    const el = document.querySelector(s);
                    if (el) {
                        const match = el.innerText.match(/\$([0-9,.]+)/);
                        if (match) return parseFloat(match[1].replace(/,/g, ''));
                    }
                }
                return 0;
            }''')
            
            page.close()
            return price
        except:
            return 0.0
