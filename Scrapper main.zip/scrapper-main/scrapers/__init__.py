"""
Módulo de scrapers - Enfocado en UnaLuka, Amazon y eBay.
"""
from .base import BaseScraper, ProductResult
from .unaluka import UnaLukaScraper
from .amazon import AmazonScraper
from .ebay import EbayScraper

__all__ = [
    'BaseScraper',
    'ProductResult',
    'UnaLukaScraper',
    'AmazonScraper',
    'EbayScraper',
]
