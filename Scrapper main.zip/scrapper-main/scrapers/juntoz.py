"""
Scraper para Juntoz Perú usando Google SERP Simulation (Evasión Total).
"""
from typing import List, Optional
from curl_cffi import requests
from bs4 import BeautifulSoup
from .base import BaseScraper, ProductResult
from utils import normalize_query
import logging
import re
import urllib.parse
import time
import random

class JuntozScraper(BaseScraper):
    """
    Scraper para Juntoz.
    Estrategia: Google SERP Simulation.
    """
    
    BASE_URL = "https://juntoz.com"
    
    @property
    def nombre_tienda(self) -> str:
        return "Juntoz"
    
    @property
    def emoji(self) -> str:
        return "🟣"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """Busca productos en Juntoz simulando búsqueda en Google."""
        results = []
        safe_query = f"site:juntoz.com {query}"
        
        tlds = ["com.pe", "com"]
        tld = random.choice(tlds)
        search_url = f"https://www.google.{tld}/search"
        
        params = {
            "q": safe_query,
            "num": max_results + 3,
            "hl": "es"
        }
        
        try:
            time.sleep(random.uniform(0.5, 1.5))
            
            response = requests.get(
                search_url,
                params=params,
                impersonate="chrome120",
                timeout=15
            )
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'lxml')
                links_seen = set()
                
                for a in soup.select('a[href]'):
                    href = a.get('href')
                    
                    if "/url?q=" in href:
                         parsed = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
                         href = parsed.get('q', [''])[0]
                    
                    if not href: continue
                    
                    # Validar dominio y patrón
                    # Juntoz suele ser juntoz.com/p/ o /producto/
                    if "juntoz.com" in href and ("/p/" in href or "/producto/" in href):
                        if href in links_seen: continue
                        links_seen.add(href)
                        
                        title_el = a.find_previous('h3') or a.find('h3')
                        if not title_el:
                            slug = href.split('/')[-1]
                            title_text = slug.replace('-', ' ').title()
                        else:
                            title_text = title_el.get_text().strip()
                            
                        # Relevance Check
                        from utils import check_relevance
                        if not check_relevance(title_text, query):
                            continue
                        
                        # Extraer Precio del Snippet
                        snippet_el = a.find_next('div', style='-webkit-line-clamp:2') or a.find_next('div', class_='VwiC3b')
                        snippet_text = snippet_el.get_text() if snippet_el else ""
                        full_text = f"{title_text} {snippet_text}"
                        
                        import re
                        price_match = re.search(r'S/\s?[\d,.]+', full_text)
                        extracted_price = 0.0
                        
                        if price_match:
                            try:
                                p_str = price_match.group(0).replace('S/', '').replace(',', '').strip()
                                extracted_price = float(p_str)
                            except:
                                pass
                        
                        results.append(ProductResult(
                            nombre=title_text,
                            precio=extracted_price,
                            precio_original=None,
                            descuento=None,
                            tienda=self.nombre_tienda,
                            url=href,
                            sku="",
                            disponible=True,
                            vendedor="Juntoz"
                        ))
                        
                        if len(results) >= max_results:
                            break
                            
        except Exception as e:
            self.logger.error(f"Error Juntoz/Google: {e}")
            
        return results
