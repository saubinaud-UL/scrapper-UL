"""
Scraper para eBay usando Playwright con JavaScript evaluation.
Soporta ambos layouts: s-item y s-card.
Optimizado para productos NUEVOS y COMPRA INMEDIATA (Buy It Now).
"""
import time
import random
import re
from typing import List, Optional
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

from .base import BaseScraper, ProductResult
from config import MIN_DELAY, MAX_DELAY
from utils import normalize_query, check_relevance


class EbayScraper(BaseScraper):
    """Scraper para eBay usando Playwright con JS evaluation."""
    
    BASE_URL = "https://www.ebay.com"
    SEARCH_URL = f"{BASE_URL}/sch/i.html"
    
    @property
    def nombre_tienda(self) -> str:
        return "eBay"
    
    @property
    def emoji(self) -> str:
        return "🔴"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """
        Busca productos en eBay usando Playwright + JavaScript.
        """
        results = []
        safe_query = normalize_query(query)
        # &_cur=USD fuerza dólar
        # &LH_ItemCondition=1000 fuerza productos NUEVOS (Critical)
        # &LH_BIN=1 fuerza COMPRA INMEDIATA (Buy It Now) -> Evita subastas con precio bajo
        search_url = f"{self.SEARCH_URL}?_nkw={safe_query.replace(' ', '+')}&_cur=USD&LH_ItemCondition=1000&LH_BIN=1"
        
        self.logger.info(f"eBay Searching: {search_url}")
        
        time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled"]
                )
                context = browser.new_context(
                    user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', # Windows UA
                    locale='en-US',
                    geolocation={'latitude': 40.7128, 'longitude': -74.0060}, # New York
                    permissions=['geolocation'],
                    timezone_id='America/New_York',
                    extra_http_headers={
                        'Accept-Language': 'en-US,en;q=0.9',
                        'X-Forwarded-For': '208.80.152.201', # Fake US IP
                        'Referer': 'https://www.google.com/'
                    }
                )
                
                # Cookie crítica para eBay force US
                context.add_cookies([
                    {
                        'name': 'dp1',
                        'value': 'bu1p/QEBfX0BAX19AQA**67cb7c2a^bl/US67cb7c2a^',
                        'domain': '.ebay.com',
                        'path': '/'
                    },
                    {
                        'name': 'ebay-locale',
                        'value': 'en-US',
                        'domain': '.ebay.com',
                        'path': '/'
                    }
                ])

                page = context.new_page()
                page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                
                page.goto(search_url, timeout=30000)
                
                # Esperar resultados
                try:
                    page.wait_for_selector('li.s-item, li.s-card', timeout=10000)
                except:
                    pass
                
                # Extraer datos usando JavaScript
                eval_result = page.evaluate(r'''() => {
                    // Intentar layout s-item primero
                    let items = document.querySelectorAll('li.s-item');
                    let layout = 's-item';
                    
                    if (items.length < 2) {
                        items = document.querySelectorAll('li.s-card');
                        layout = 's-card';
                    }
                    
                    const results = [];
                    
                    items.forEach((item, index) => {
                        let title = '';
                        let link = '';
                        let condition = '';
                        let price = 0;
                        
                        // Selectores según layout
                        const titleSelector = layout === 's-item' ? '.s-item__title' : '.s-card__title span';
                        const priceSelector = layout === 's-item' ? '.s-item__price' : '.s-card__price';
                        const linkSelector = layout === 's-item' ? 'a.s-item__link' : 'a.s-card__link';
                        const condSelector = layout === 's-item' ? '.s-item__subtitle' : '.s-card__subtitle span';
                        
                        // Extraer título
                        const titleEl = item.querySelector(titleSelector);
                        title = titleEl ? titleEl.textContent.trim() : '';
                        
                        // Link
                        const linkEl = item.querySelector(linkSelector);
                        link = linkEl ? linkEl.href : '';
                        
                        // Condición
                        const condEl = item.querySelector(condSelector);
                        condition = condEl ? condEl.textContent.trim() : '';
                        
                        // Precio Texto
                        const priceEl = item.querySelector(priceSelector);
                        let priceText = priceEl ? priceEl.textContent : '';
                        const originalText = priceText;
                        
                        // LOGICA STRICTA DE DOLARES (SIN CONVERSION)
                        
                        // 1. Limpiar rangos "to"
                        if (priceText.toLowerCase().includes(' to ')) {
                            priceText = priceText.split(/\s+to\s+/i)[0];
                        }
                        
                        // 2. Extraer monto USD explícito
                        let extracted = false;
                        
                        // Buscamos "US $123.45" o "$123.45"
                        let match = priceText.match(/US\s*\$\s*([0-9,.]+)/);
                        
                        if (match) {
                            priceText = match[1];
                            extracted = true;
                        } else {
                            if (!priceText.includes('S/') && !priceText.includes('PEN')) {
                                match = priceText.match(/\$\s*([0-9,.]+)/);
                                if (match) {
                                    priceText = match[1];
                                    extracted = true;
                                }
                            }
                        }
                        
                        if (extracted) {
                            // Limpiar y parsear formato US (1,234.56)
                            priceText = priceText.replace(/,/g, ''); // Quitar separador de miles
                            price = parseFloat(priceText) || 0;
                        } else {
                            // Si es Soles, marcamos con -1 para indicar "Need Fetch"
                            // Solo si NO es "Shop on eBay"
                            if (priceText.includes('S/') || priceText.includes('PEN')) {
                                price = -1.0; 
                            } else {
                                price = 0;
                            }
                        }

                        // Skip "Shop on eBay" placeholder
                        if (title && title.toLowerCase().includes('shop on ebay')) {
                            return;
                        }
                        
                        if (title && price != 0) {
                            results.push({
                                title: title,
                                price: price,
                                link: link,
                                condition: condition,
                                raw_price: originalText
                            });
                        }
                    });
                    
                    return results;
                }''')
                
                items_data = eval_result
                
                self.logger.info(f"eBay: Found {len(items_data)} potential items via JS")
                
                valid_results_count = 0
                for item in items_data:
                    if len(results) >= max_results:
                        break
                    
                    # Si el precio es -1 (Soles), navegar al producto para sacar USD
                    if item['price'] == -1.0:
                        self.logger.info(f"eBay Fetching Detail for USD: {item['link']}")
                        try:
                            # Navegar al detalle
                            detail_page = context.new_page()
                            detail_page.goto(item['link'], timeout=15000)
                            try:
                                detail_page.wait_for_selector('.x-price-primary, .main-price-with-content', timeout=5000)
                            except:
                                pass
                                
                            usd_price = detail_page.evaluate(r'''() => {
                                // Buscar selectores de precio detalle
                                const selectors = ['.x-price-primary', '.main-price-with-content', '.x-price-approx__price', '.display-price'];
                                for (let s of selectors) {
                                    const el = document.querySelector(s);
                                    if (el && el.textContent.includes('US') && el.textContent.includes('$')) {
                                        return el.textContent;
                                    }
                                }
                                return null;
                            }''')
                            
                            detail_page.close()
                            
                            if usd_price:
                                # Parsear "US $338.00"
                                import re
                                match = re.search(r'US\s*\$\s*([0-9,.]+)', usd_price)
                                if match:
                                    p_txt = match.group(1).replace(',', '')
                                    val = float(p_txt)
                                    # Sanity Check > 5.0 (Re-added)
                                    if val > 5.0:
                                        item['price'] = val
                                        self.logger.info(f"  -> Found USD: {item['price']}")
                                    else:
                                        self.logger.warning(f"  -> Ignored suspicious low price: {val}")
                                        continue
                                else:
                                    self.logger.warning(f"  -> Could not parse USD from '{usd_price}'")
                                    continue # Skip this item
                            else:
                                self.logger.warning("  -> No USD price found on detail page")
                                continue # Skip
                        except Exception as e:
                            self.logger.error(f"Error fetching detail {item['link']}: {e}")
                            continue
                            
                    # Relevance check
                    if not check_relevance(item['title'], query):
                        continue
                    
                    # Sanity Check final para listas principales
                    if item['price'] <= 5.0:
                         continue

                    vendedor = "eBay"
                    if item.get('condition'):
                        vendedor = f"eBay ({item['condition']})"
                    
                    results.append(ProductResult(
                        nombre=item['title'],
                        precio=item['price'],
                        precio_original=None,
                        descuento=None,
                        tienda=self.nombre_tienda,
                        url=item['link'],
                        sku="",
                        disponible=True,
                        vendedor=vendedor
                    ))
                    valid_results_count += 1
                
                browser.close()
                
        except PlaywrightTimeout:
            self.logger.error("Timeout esperando resultados de eBay")
        except Exception as e:
            self.logger.error(f"Error Playwright eBay: {e}")
            
        return results
