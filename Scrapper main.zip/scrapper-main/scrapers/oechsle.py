"""
Scraper para Oechsle Perú usando API directa (VTEX) y curl_cffi.
"""
from typing import List, Optional
from curl_cffi import requests
from .base import BaseScraper, ProductResult
from utils import normalize_query
import logging

class OechsleScraper(BaseScraper):
    """Scraper para Oechsle Perú usando API VTEX."""
    
    # VTEX Search API (Standard FT param is more robust than path)
    SEARCH_API = "https://www.oechsle.pe/api/catalog_system/pub/products/search?ft={query}"
    
    @property
    def nombre_tienda(self) -> str:
        return "Oechsle"
    
    @property
    def emoji(self) -> str:
        return "🔵"
    
    def search(self, query: str, max_results: int = 5) -> List[ProductResult]:
        """Busca productos en Oechsle vía API."""
        results = []
        safe_query = normalize_query(query)
        # Encode for URL param
        import urllib.parse
        encoded_query = urllib.parse.quote(safe_query)
        
        url = self.SEARCH_API.format(query=encoded_query)
        
        try:
            response = requests.get(
                url,
                impersonate="chrome120",
                timeout=15
            )
            
            if response.status_code in [200, 206]:
                data = response.json()
                
                from utils import check_relevance # Import local
                
                for item in data: # Scan more items to find relevant ones
                    try:
                        nombre = item.get('productName', '')
                        
                        # Strict Relevance Check
                        if not check_relevance(nombre, query):
                            continue
                            
                        link_text = item.get('linkText', '')
                        url = item.get('link', '')
                        
                        # Precio logic in VTEX is complex, inside 'items' > 'sellers' > 'commertialOffer'
                        sku = item.get('items', [{}])[0]
                        seller = sku.get('sellers', [{}])[0]
                        offer = seller.get('commertialOffer', {})
                        
                        price = float(offer.get('Price', 0))
                        list_price = float(offer.get('ListPrice', 0)) or None
                        available = offer.get('AvailableQuantity', 0) > 0
                        
                        if not available:
                            continue
                            
                        results.append(ProductResult(
                            nombre=nombre,
                            precio=price,
                            precio_original=list_price,
                            descuento=None, # Calculate later if needed
                            tienda=self.nombre_tienda,
                            url=url,
                            sku=sku.get('itemId', ''),
                            disponible=available,
                            vendedor="Oechsle"
                        ))
                    except Exception as e:
                        self.logger.warning(f"Error parsing Oechsle item: {e}")
                        continue
                        
        except Exception as e:
            self.logger.error(f"Error Oechsle API: {e}")
            
        return results
